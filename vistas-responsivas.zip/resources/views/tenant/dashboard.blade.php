<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - {{ $tenant->academy_name }}</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=Inter:wght@300;400;500;600&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root { --bg: #0a0a14; --surface: rgba(123,47,190,0.08); --primary: #9D4EDD; --accent: #E0AAFF; --text: #F0E6FF; --muted: #a78bca; --border: rgba(157,78,221,0.3); }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; }
        nav { display: flex; justify-content: space-between; padding: 1rem 3rem; background: rgba(255,255,255,0.02); border-bottom: 1px solid var(--border); align-items: center; }
        .logo { font-family: 'Syne'; font-weight: 800; font-size: 1.2rem; color: var(--primary); }
        .user-menu { display: flex; align-items: center; gap: 1.5rem; }
        .notification-bell { position: relative; cursor: pointer; font-size: 1.2rem; }
        .badge { position: absolute; top: -5px; right: -8px; background: #FF6B6B; color: #fff; font-size: 0.6rem; padding: 2px 5px; border-radius: 10px; font-family: 'Space Grotesk'; font-weight: 600; }
        .container { padding: 3rem; max-width: 1200px; margin: 0 auto; }
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: 15px; padding: 2rem; margin-bottom: 2rem; }
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; margin: 2rem 0; }
        .stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: 15px; padding: 2rem; text-align: center; }
        .stat-value { font-family: 'Syne'; font-size: 2.5rem; font-weight: 700; color: var(--accent); margin-bottom: 0.5rem; }
        .stat-label { font-family: 'Space Grotesk'; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; font-size: 0.8rem; }
        .form-group { margin-bottom: 1rem; }
        label { display:block; margin-bottom:0.5rem; color:var(--accent); }
        input, select, textarea { width:100%; background:rgba(0,0,0,0.3); border:1px solid var(--border); border-radius:10px; padding:0.8rem; color:var(--text); }
        .btn { background:linear-gradient(135deg,var(--primary),#6a1eb0); color:#fff; border:none; padding:1rem; border-radius:10px; cursor:pointer; font-family:'Space Grotesk',sans-serif; font-weight:600;}
        .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .student-form { display:grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 1rem; align-items: end; margin-bottom: 2rem; }
        @media(max-width:768px) {
            nav { flex-direction: column; gap: 1rem; text-align: center; }
            .student-form { grid-template-columns: 1fr; align-items: stretch; }
            .container { padding: 1rem; }
            .card { padding: 1.5rem; }
        }
    </style>
</head>
<body>
    <nav>
        <div class="logo">{{ $tenant->academy_name }}</div>
        <div class="user-menu">
            <div class="notification-bell" onclick="alert('Notificaciones leídas')">
                🔔 <span class="badge" id="notif-count">0</span>
            </div>
            <div>{{ auth()->user()->name }} <a href="{{ route('logout') }}" style="color:var(--accent); text-decoration: none;">(Salir)</a></div>
        </div>
    </nav>
    
    <div class="container">
        <h1>Bienvenido, {{ auth()->user()->name }}</h1>
        <p style="color:var(--muted)">Plan actual: <strong>{{ strtoupper($tenant->plan) }}</strong></p>

        
        @if(session('error'))
            <div style="background: rgba(255,107,107,0.1); border: 1px solid #FF6B6B; color: #FF6B6B; padding: 1rem; border-radius: 10px; margin-bottom: 2rem;">
                ⚠️ {{ session('error') }}
            </div>
        @endif
        @if(session('success'))
            <div style="background: rgba(157,78,221,0.1); border: 1px solid var(--primary); color: var(--text); padding: 1rem; border-radius: 10px; margin-bottom: 2rem;">
                ✅ {{ session('success') }}
            </div>
        @endif

        <div class="stats-grid">

            <div class="stat-card">
                <div class="stat-value">{{ $stats['players'] }}</div>
                <div class="stat-label">Alumnos Activos</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ $stats['categories'] }}</div>
                <div class="stat-label">Categorías</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${{ number_format($stats['revenue'], 2) }}</div>
                <div class="stat-label">Ingresos Registrados</div>
            </div>
        </div>

        <div class="card">
            <h3>Gestión Rápida de Alumnos</h3>
            <p style="color:var(--muted); margin-bottom:1rem;">Añade alumnos y visualiza los registrados en tu academia. El límite depende de tu plan (Básico: 40, Elite: 150, Premium: Ilimitado).</p>
            
            <form action="{{ route('tenant.players.store') }}" method="POST" class="student-form">
                @csrf
                <div class="form-group" style="margin:0;">
                    <label>Nombre</label>
                    <input type="text" name="first_name" required>
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Apellidos</label>
                    <input type="text" name="last_name" required>
                </div>
                <div class="form-group" style="margin:0;">
                    <label>Fecha Nacimiento</label>
                    <input type="date" name="birth_date" required>
                </div>
                <button type="submit" class="btn">➕ Añadir</button>
            </form>

            <div class="table-responsive">
                <table style="width:100%; border-collapse: collapse; text-align: left; min-width: 600px;">
                    <thead>
                        <tr style="border-bottom: 1px solid var(--border);">
                            <th style="padding: 1rem; color: var(--muted);">Nombre</th>
                            <th style="padding: 1rem; color: var(--muted);">Apellidos</th>
                            <th style="padding: 1rem; color: var(--muted);">Fecha de Nacimiento</th>
                            <th style="padding: 1rem; color: var(--muted);">Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($players as $player)
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 1rem;">{{ $player->first_name }}</td>
                            <td style="padding: 1rem;">{{ $player->last_name }}</td>
                            <td style="padding: 1rem;">{{ $player->birth_date }}</td>
                            <td style="padding: 1rem;"><span style="background: var(--primary); padding: 2px 8px; border-radius: 10px; font-size: 0.8rem;">{{ $player->status }}</span></td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="4" style="padding: 1rem; text-align:center; color: var(--muted);">No hay alumnos registrados aún.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h3>Demo: Enviar Notificación Push</h3>
            <p style="color:var(--muted);margin-bottom:1rem">Usa este formulario para simular el envío de una notificación en tiempo real a los padres.</p>
            <form action="{{ route('tenant.notifications.send') }}" method="POST">
                @csrf
                <div class="form-group">
                    <label>Tipo</label>
                    <select name="type">
                        <option value="global">Anuncio Global (Para todos)</option>
                        <option value="specific">Cobro / Alerta Específica</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Título del Mensaje</label>
                    <input type="text" name="title" required placeholder="Ej. Partido Cancelado">
                </div>
                <div class="form-group" style="margin-top:1rem">
                    <label>Mensaje</label>
                    <textarea name="message" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn" style="margin-top:1rem">🚀 Enviar Notificación</button>
            </form>
        </div>
    </div>

    <script>
        // Polling para simular notificaciones instantáneas en la presentación
        setInterval(async () => {
            try {
                const res = await fetch('/api/notifications/unread');
                const data = await res.json();
                if (data.notifications && data.notifications.length > 0) {
                    let count = parseInt(document.getElementById('notif-count').innerText);
                    count += data.notifications.length;
                    document.getElementById('notif-count').innerText = count;
                    
                    data.notifications.forEach(n => {
                        Swal.fire({
                            title: n.data.title,
                            text: n.data.message,
                            icon: 'info',
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 5000,
                            timerProgressBar: true,
                            background: '#0a0a14',
                            color: '#F0E6FF',
                        });
                    });
                }
            } catch (e) {}
        }, 3000); // Revisa cada 3 segundos
    </script>
</body>
</html>
