<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperAdmin - Dark Amethyst</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@000;700;800&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root { --bg: #0a0a14; --surface: rgba(123,47,190,0.08); --primary: #9D4EDD; --text: #F0E6FF; --border: rgba(157,78,221,0.3); }
        body { background:var(--bg); color:var(--text); font-family:'Inter'; padding: 2rem; }
        .table { width: 100%; border-collapse: collapse; margin-top: 2rem; min-width: 600px; }
        .table th, table td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--border); }
        .table th { color: var(--primary); }
        .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        @media(max-width:768px) {
            body { padding: 1rem; }
        }
    </style>
</head>
<body>
    <h1 style="font-family:'Syne';">Panel SuperAdmin</h1>
    <p>Resumen de Academias (Tenants) en el SaaS</p>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>Academia</th><th>Subdominio</th><th>Plan</th><th>Estado</th></tr>
            </thead>
            <tbody>
                @foreach($tenants as $t)
                <tr>
                    <td>{{ $t->academy_name }}</td>
                    <td>{{ $t->subdomain }}.academiahe5.com</td>
                    <td>{{ strtoupper($t->plan) }}</td>
                    <td>{{ strtoupper($t->status) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>