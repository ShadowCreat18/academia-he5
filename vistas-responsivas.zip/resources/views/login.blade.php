<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - AcademiaCloud</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=Inter:wght@300;400;500;600&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root { --bg: #0a0a14; --surface: rgba(123,47,190,0.08); --primary: #9D4EDD; --accent: #E0AAFF; --text: #F0E6FF; --muted: #a78bca; --border: rgba(157,78,221,0.3); --glow: 0 0 24px rgba(157,78,221,0.4); }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; position: relative; }
        body::before { content:''; position:fixed; inset:0; z-index:-1; background: radial-gradient(ellipse 80% 50% at 50% -20%, rgba(123,47,190,0.25) 0%, transparent 70%), radial-gradient(ellipse 50% 40% at 80% 80%, rgba(157,78,221,0.12) 0%, transparent 60%); }
        .container { max-width: 400px; width: 100%; padding: 2rem; }
        .logo { text-align: center; font-family: 'Syne',sans-serif; font-size: 1.5rem; font-weight: 800; background: linear-gradient(135deg, var(--accent), var(--primary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 2rem; }
        .card { background: var(--surface); border: 1px solid var(--border); border-radius: 20px; padding: 2.5rem; backdrop-filter: blur(16px); box-shadow: 0 8 32px rgba(0,0,0,0.3); }
        .title { font-family: 'Syne',sans-serif; font-size: 1.75rem; margin-bottom: 0.5rem; text-align: center; }
        .subtitle { color: var(--muted); font-size: 0.9rem; text-align: center; margin-bottom: 2rem; }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; font-family: 'Space Grotesk',sans-serif; font-size: 0.85rem; color: var(--accent); margin-bottom: 0.5rem; }
        input { width: 100%; background: rgba(0,0,0,0.3); border: 1px solid var(--border); border-radius: 10px; padding: 0.8rem 1rem; color: var(--text); font-family: 'Inter',sans-serif; transition: all 0.2s; }
        input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 2px rgba(157,78,221,0.2); }
        .btn-submit { width: 100%; background: linear-gradient(135deg, var(--primary), #6a1eb0); color: #fff; border: none; padding: 1rem; border-radius: 10px; font-family: 'Space Grotesk',sans-serif; font-weight: 600; font-size: 1rem; cursor: pointer; box-shadow: var(--glow); transition: all 0.2s; margin-top: 1rem; }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 0 40px rgba(157,78,221,0.65); }
        @media(max-width: 480px) {
            .container { padding: 1rem; }
            .card { padding: 1.5rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">DARK AMETHYST STUDIO</div>
        <div class="card">
            <h1 class="title">Iniciar Sesión</h1>
            
            <div style="background: rgba(157,78,221,0.15); border: 1px solid var(--primary); padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem; text-align: center; font-size: 0.9rem;">
                <strong style="color: var(--accent);">¿Quieres probar el Demo?</strong><br>
                <span style="color: var(--muted);">Email:</span> demo@academiahe5.com<br>
                <span style="color: var(--muted);">Contraseña:</span> demo1234
            </div>

            <form action="{{ route('login.post') }}" method="POST">
                @csrf
                <div class="form-group">
                    <label>Correo Electrónico</label>
                    <input type="email" name="email" required placeholder="admin@ejemplo.com">
                </div>
                <div class="form-group">
                    <label>Contraseña</label>
                    <input type="password" name="password" required placeholder="ャャャャャ">
                </div>
                <button type="submit" class="btn-submit">Entrar</button>
            </form>
        </div>
    </div>
</body>
</html>